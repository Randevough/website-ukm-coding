/**
 * Cursor-aligned grid reveal (Deprecated).
 *
 * Replaced by a purely CSS-based hardware-accelerated counter-transform animation
 * in hero-effects.css to eliminate GPU/CPU repaints and improve performance.
 */
export {};
