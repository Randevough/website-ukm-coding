/* =========================================================
   MOTION — semua gerak di satu tempat
   1. reveal      : kemunculan bertahap saat masuk layar
   2. lineMask    : baris judul hero naik dari masker
   3. parallax    : kedalaman saat scroll (transform, bukan bg)
   4. counter     : angka berhitung naik
   5. tilt        : kartu miring mengikuti kursor
   6. cursor      : label kursor kustom "Lihat cepat"
   7. ticker      : baris berjalan (klon isi supaya mulus)
   8. heroWash    : sapuan gradient mengikuti pointer
   ========================================================= */

window.Motion = (function () {
	"use strict";

	const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	const qsa = (sel, root) =>
		Array.prototype.slice.call((root || document).querySelectorAll(sel));

	/* ---------------- 1 + 2. Reveal & lineMask ---------------- */
	let io = null;

	function initReveal(root) {
		const targets = qsa(
			"[data-reveal]:not(.is-in), [data-rule]:not(.is-in), .lineMask:not(.is-in)",
			root,
		);
		if (!targets.length) return;

		if (reduce) {
			targets.forEach((el) => el.classList.add("is-in"));
			return;
		}

		if (!io) {
			io = new IntersectionObserver(
				(entries) => {
					entries.forEach((entry) => {
						if (!entry.isIntersecting) return;
						entry.target.classList.add("is-in");
						io.unobserve(entry.target);
					});
				},
				{ rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
			);
		}

		/* Stagger otomatis: elemen bersaudara dalam satu grup diberi
		   jeda beruntun supaya kemunculannya berirama, tidak serentak. */
		qsa("[data-stagger]", root).forEach((group) => {
			const step = parseInt(group.getAttribute("data-stagger"), 10) || 70;
			qsa("[data-reveal], .lineMask", group).forEach((el, i) => {
				if (!el.style.getPropertyValue("--reveal-delay")) {
					el.style.setProperty("--reveal-delay", i * step + "ms");
				}
			});
		});

		targets.forEach((el) => io.observe(el));
	}

	/* Hero harus langsung jalan tanpa menunggu scroll. */
	function playHero(root) {
		qsa(".lineMask", root).forEach((el, i) => {
			if (!el.style.getPropertyValue("--reveal-delay")) {
				el.style.setProperty("--reveal-delay", 90 + i * 110 + "ms");
			}
		});
		requestAnimationFrame(() => {
			qsa(".hero .lineMask, .hero [data-reveal], .hero [data-rule]", root).forEach(
				(el) => el.classList.add("is-in"),
			);
		});
	}

	/* ---------------- 3. Parallax ---------------- */
	let pxItems = [];
	let pxTicking = false;

	function collectParallax(root) {
		pxItems = qsa("[data-parallax]", root || document).map((el) => ({
			el: el,
			speed: parseFloat(el.getAttribute("data-parallax")) || 0.12,
		}));
		if (pxItems.length) applyParallax();
	}

	function applyParallax() {
		const vh = window.innerHeight;
		pxItems.forEach((item) => {
			const rect = item.el.getBoundingClientRect();
			if (rect.bottom < -200 || rect.top > vh + 200) return;
			/* Titik nol saat elemen berada di tengah layar — supaya
			   pergeseran terasa simetris, tidak menumpuk ke bawah. */
			const offset = rect.top + rect.height / 2 - vh / 2;
			const shift = -offset * item.speed;
			item.el.style.transform = "translate3d(0," + shift.toFixed(2) + "px,0)";
		});
	}

	function onScrollParallax() {
		if (pxTicking) return;
		pxTicking = true;
		requestAnimationFrame(() => {
			applyParallax();
			pxTicking = false;
		});
	}

	function initParallax(root) {
		if (reduce) return;
		collectParallax(root);
		window.removeEventListener("scroll", onScrollParallax);
		window.addEventListener("scroll", onScrollParallax, { passive: true });
		window.addEventListener("resize", onScrollParallax);
	}

	/* ---------------- 4. Counter ---------------- */
	function runCounter(el) {
		const target = parseFloat(el.getAttribute("data-counter")) || 0;
		const suffix = el.getAttribute("data-suffix") || "";
		const dur = 1500;
		const start = performance.now();

		if (reduce) {
			el.innerHTML = target + (suffix ? "<sup>" + suffix + "</sup>" : "");
			return;
		}

		function frame(now) {
			const t = Math.min(1, (now - start) / dur);
			/* easeOutExpo — cepat di awal, mendarat halus di angka akhir */
			const e = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
			const val = Math.round(target * e);
			el.innerHTML = val + (suffix ? "<sup>" + suffix + "</sup>" : "");
			if (t < 1) requestAnimationFrame(frame);
		}
		requestAnimationFrame(frame);
	}

	function initCounters(root) {
		const items = qsa("[data-counter]:not(.is-counted)", root);
		if (!items.length) return;
		const obs = new IntersectionObserver(
			(entries) => {
				entries.forEach((entry) => {
					if (!entry.isIntersecting) return;
					entry.target.classList.add("is-counted");
					runCounter(entry.target);
					obs.unobserve(entry.target);
				});
			},
			{ threshold: 0.4 },
		);
		items.forEach((el) => obs.observe(el));
	}

	/* ---------------- 5. Tilt ---------------- */
	function initTilt(root) {
		if (reduce || window.matchMedia("(hover: none)").matches) return;
		qsa("[data-tilt]", root).forEach((card) => {
			let raf = null;

			const move = (e) => {
				const r = card.getBoundingClientRect();
				const px = (e.clientX - r.left) / r.width - 0.5;
				const py = (e.clientY - r.top) / r.height - 0.5;
				if (raf) cancelAnimationFrame(raf);
				raf = requestAnimationFrame(() => {
					card.style.transform =
						"perspective(900px) rotateX(" +
						(-py * 4.2).toFixed(2) +
						"deg) rotateY(" +
						(px * 5.4).toFixed(2) +
						"deg) translateZ(0)";
				});
			};

			const leave = () => {
				if (raf) cancelAnimationFrame(raf);
				card.style.transform = "";
			};

			card.addEventListener("pointermove", move);
			card.addEventListener("pointerleave", leave);
		});
	}

	/* ---------------- 6. Kursor kustom ---------------- */
	let cursorEl = null;

	function initCursor(root) {
		if (window.matchMedia("(hover: none)").matches) return;
		const zones = qsa("[data-cursor]", root);
		if (!zones.length) return;

		if (!cursorEl) {
			cursorEl = document.createElement("div");
			cursorEl.className = "cursor";
			cursorEl.setAttribute("aria-hidden", "true");
			document.body.appendChild(cursorEl);
		}

		let x = 0;
		let y = 0;
		let cx = 0;
		let cy = 0;
		let on = false;
		let raf = null;

		function loop() {
			/* Sedikit tertinggal dari pointer supaya terasa punya berat. */
			cx += (x - cx) * 0.22;
			cy += (y - cy) * 0.22;
			cursorEl.style.transform =
				"translate3d(" + cx.toFixed(1) + "px," + cy.toFixed(1) + "px,0) translate(-50%,-50%)";
			if (on) raf = requestAnimationFrame(loop);
			else raf = null;
		}

		zones.forEach((zone) => {
			zone.addEventListener("pointerenter", () => {
				cursorEl.textContent = zone.getAttribute("data-cursor") || "Lihat";
				cursorEl.classList.add("is-on");
				on = true;
				if (!raf) raf = requestAnimationFrame(loop);
			});
			zone.addEventListener("pointerleave", () => {
				cursorEl.classList.remove("is-on");
				on = false;
			});
			zone.addEventListener("pointermove", (e) => {
				x = e.clientX;
				y = e.clientY;
				if (cx === 0 && cy === 0) {
					cx = x;
					cy = y;
				}
			});
		});
	}

	/* ---------------- 7. Ticker ---------------- */
	function initTicker(root) {
		qsa(".ticker:not(.is-ready)", root).forEach((ticker) => {
			const track = ticker.querySelector(".ticker__track");
			if (!track) return;
			/* Klon isi satu kali: animasi -100% jadi mulus tanpa jeda. */
			const clone = track.cloneNode(true);
			clone.setAttribute("aria-hidden", "true");
			ticker.appendChild(clone);
			ticker.classList.add("is-ready");
		});
	}

	/* ---------------- 8. Sapuan hero ---------------- */
	function initHeroWash(root) {
		const wash = (root || document).querySelector(".hero__wash");
		if (!wash || reduce) return;
		const hero = wash.closest(".hero");
		if (!hero) return;

		let raf = null;
		hero.addEventListener("pointermove", (e) => {
			const r = hero.getBoundingClientRect();
			const mx = ((e.clientX - r.left) / r.width) * 100;
			const my = ((e.clientY - r.top) / r.height) * 100;
			if (raf) cancelAnimationFrame(raf);
			raf = requestAnimationFrame(() => {
				wash.style.setProperty("--mx", mx.toFixed(1) + "%");
				wash.style.setProperty("--my", my.toFixed(1) + "%");
			});
		});
	}

	/* ---------------- Boot ---------------- */
	function initAll(root) {
		const scope = root || document;
		initReveal(scope);
		playHero(scope);
		initParallax(scope);
		initCounters(scope);
		initTilt(scope);
		initCursor(scope);
		initTicker(scope);
		initHeroWash(scope);
	}

	return {
		initAll: initAll,
		initReveal: initReveal,
		initParallax: initParallax,
		initCounters: initCounters,
		initTilt: initTilt,
		initCursor: initCursor,
		initTicker: initTicker,
		initHeroWash: initHeroWash,
		playHero: playHero,
		reduce: reduce,
	};
})();
