/* =========================================================
   HOME V2 — render ulang tiga blok beranda
   1. Projects pilihan  : kartu ringkas + modal lihat cepat
   2. Updates           : baris editorial + thumbnail saat hover
   3. Galeri kegiatan   : mosaic asimetris 6 frame
   Dimuat setelah App.boot(), jadi cukup menimpa isi slot.
   ========================================================= */

window.HomeV2 = (function () {
	"use strict";

	var D = window.UKM;
	var U = window.UI;
	var M = window.Motion;

	function esc(s) {
		return U.esc(s);
	}

	function glyphOf(text) {
		return String(text || "?")
			.replace(/[^A-Za-z0-9 ]/g, "")
			.split(" ")
			.filter(Boolean)
			.slice(0, 2)
			.map(function (w) {
				return w[0].toUpperCase();
			})
			.join("");
	}

	function specRow(k, v) {
		if (!v) return "";
		return (
			'<div class="spec__row"><span class="spec__k">' +
			esc(k) +
			'</span><span class="spec__v">' +
			esc(v) +
			"</span></div>"
		);
	}

	/* ---------------- 1. Projects ---------------- */
	function cardHtml(p, i) {
		var stack = Array.isArray(p.stack) ? p.stack : [];
		return (
			'<article class="pcard pcard--v2" data-project="' +
			esc(p.slug) +
			'" data-reveal tabindex="0" role="button" aria-expanded="false" aria-label="Buka ringkasan ' +
			esc(p.title) +
			'">' +
			'<div class="pcard__art">' +
			U.art(p.variant, glyphOf(p.title)) +
			"</div>" +
			'<div class="pcard__top"><span class="label">' +
			(String(i + 1).padStart(2, "0") + " \u00b7 ") +
			esc(p.kategori) +
			'</span><span class="idx">' +
			esc(p.tahun) +
			"</span></div>" +
			'<div class="pcard__body"><h3 class="pcard__title">' +
			esc(p.title) +
			'</h3><p class="pcard__one">' +
			esc(p.oneLiner) +
			"</p></div>" +
			'<div class="pcard__foot"><span class="mono">' +
			esc(stack.slice(0, 3).join(" / ")) +
			'</span><span class="pcard__cue" data-cue>Lihat ringkas <span class="arrow">\u2192</span></span></div>' +
			"</article>"
		);
	}

	function openProjectModal(slug) {
		var modal = document.getElementById("projectModal");
		var body = document.getElementById("projectModalBody");
		var p = D.projects.filter(function (x) {
			return x.slug === slug;
		})[0];
		if (!modal || !body || !p) return;
		var stack = Array.isArray(p.stack) ? p.stack : [];
		body.innerHTML =
			'<div class="modal__art">' +
			U.art(p.variant, glyphOf(p.title)) +
			"</div>" +
			'<div class="modal__body">' +
			'<span class="label label--mark">' +
			esc(p.kategori) +
			" \u00b7 " +
			esc(p.tahun) +
			"</span>" +
			'<h2 id="projectModalTitle">' +
			esc(p.title) +
			"</h2>" +
			'<p class="dek">' +
			esc(p.oneLiner) +
			"</p>" +
			'<div class="spec">' +
			specRow("Peran", p.peran) +
			specRow("Status", p.status) +
			specRow("Kontributor", p.kontributor) +
			specRow("Tahun", p.tahun) +
			"</div>" +
			'<div class="stackpills">' +
			stack
				.map(function (x) {
					return '<span class="stackpill">' + esc(x) + "</span>";
				})
				.join("") +
			"</div>" +
			'<div class="row">' +
			'<a class="btn btn--primary" href="showcase-detail.html?slug=' +
			esc(p.slug) +
			'">Buka detail project <span class="arrow">\u2192</span></a>' +
			'<button class="btn" type="button" data-modal-close>Tutup</button>' +
			"</div>" +
			"</div>";
		U.openModal(modal);
	}

	function renderProjects() {
		var grid = document.getElementById("featuredProjects");
		if (!grid) return;
		var list = D.projects
			.filter(function (p) {
				return p.featured;
			})
			.slice(0, 3);
		if (!list.length) list = D.projects.slice(0, 3);
		grid.innerHTML = list.map(cardHtml).join("");

		U.qsa("[data-project]", grid).forEach(function (card) {
			function open() {
				openProjectModal(card.getAttribute("data-project"));
			}
			card.addEventListener("click", function (e) {
				if (e.target.closest("a")) return;
				open();
			});
			card.addEventListener("keydown", function (e) {
				if (e.target !== card) return;
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault();
					open();
				}
			});
		});
	}

	/* ---------------- 2. Updates ---------------- */
	function renderUpdates() {
		var slot = document.getElementById("latestPosts");
		if (!slot) return;
		var posts = D.posts.slice(0, 5);
		slot.className = "urows";
		slot.innerHTML = posts
			.map(function (post, i) {
				return (
					'<a class="urow" data-reveal href="berita-detail.html?slug=' +
					esc(post.slug) +
					'">' +
					'<span class="urow__idx">' +
					String(i + 1).padStart(2, "0") +
					"</span>" +
					"<div>" +
					'<span class="urow__kat">' +
					esc(post.kategori) +
					"</span>" +
					'<h3 class="urow__title">' +
					esc(post.title) +
					"</h3>" +
					"</div>" +
					'<span class="urow__meta">' +
					esc(post.penulis || "") +
					"</span>" +
					'<span class="urow__date">' +
					U.tanggalPendek(post.tanggal) +
					"</span>" +
					'<span class="urow__arrow">\u2192</span>' +
					'<span class="urow__thumb" aria-hidden="true">' +
					U.art(post.variant, glyphOf(post.kategori)) +
					"</span>" +
					"</a>"
				);
			})
			.join("");
	}

	/* ---------------- 3. Galeri ---------------- */
	function renderGallery() {
		var slot = document.getElementById("ig");
		if (!slot) return;
		var items = D.instagram.slice(0, 6);
		slot.innerHTML = items
			.map(function (g) {
				return (
					'<a class="igtile" data-no-router="true" rel="noopener" target="_blank" href="' +
					esc(D.settings.instagramUrl) +
					'">' +
					U.art(g.variant, "IG") +
					'<span class="igtile__overlay">' +
					esc(g.caption) +
					"</span>" +
					"</a>"
				);
			})
			.join("");
	}

	function apply() {
		if (!D || !U) return;
		if (document.body.getAttribute("data-page") !== "home") return;
		renderProjects();
		renderUpdates();
		renderGallery();
		if (M && M.initReveal) M.initReveal(document.getElementById("page"));
	}

	apply();

	return { apply: apply };
})();
