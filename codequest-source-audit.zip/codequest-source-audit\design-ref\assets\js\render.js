/* =========================================================
   RENDER — mengisi seluruh slot halaman dari window.UKM
   Satu berkas, dikelompokkan per halaman.
   Menyediakan window.App.boot() dan window.App.mount(root).
   ========================================================= */

window.App = (function () {
	"use strict";

	const D = window.UKM;
	const U = window.UI;
	const M = window.Motion;
	const esc = U.esc;

	function set(el, html) {
		if (el) el.innerHTML = html;
	}

	function glyphOf(text) {
		return String(text || "?")
			.replace(/[^A-Za-z0-9 ]/g, "")
			.split(" ")
			.filter(Boolean)
			.slice(0, 2)
			.map((w) => w[0].toUpperCase())
			.join("");
	}

	/* =====================================================
	   Pengaturan global (surel, tagline, tahun, nav aktif)
	   ===================================================== */
	function fillSettings() {
		U.qsa("[data-set]").forEach((el) => {
			const key = el.getAttribute("data-set");
			if (D.settings[key] != null && D.settings[key] !== "") {
				el.textContent = D.settings[key];
			}
		});
		U.qsa("[data-mailto]").forEach((el) => {
			el.setAttribute("href", "mailto:" + D.settings.email);
		});
	}

	/* =====================================================
	   Potongan markup yang dipakai berulang
	   ===================================================== */

	/* Kartu project untuk kisi bento. */
	function pcard(p, size, i) {
		const mod = size === "tall" ? " pcard--tall" : size === "wide" ? " pcard--wide" : "";
		return (
			'<article class="pcard' +
			mod +
			'" data-project="' +
			esc(p.slug) +
			'" data-tilt data-reveal tabindex="0" role="button" aria-label="Lihat cepat ' +
			esc(p.title) +
			'">' +
			'<div class="pcard__art">' +
			U.art(p.variant, glyphOf(p.title)) +
			"</div>" +
			'<div class="pcard__top">' +
			'<span class="label">' +
			(i != null ? String(i + 1).padStart(2, "0") + " · " : "") +
			esc(p.kategori) +
			"</span>" +
			'<span class="idx">' +
			esc(p.tahun) +
			"</span>" +
			"</div>" +
			'<div class="pcard__body">' +
			'<h3 class="pcard__title">' +
			esc(p.title) +
			"</h3>" +
			'<p class="pcard__one">' +
			esc(p.oneLiner) +
			"</p>" +
			"</div>" +
			'<div class="pcard__foot">' +
			'<span class="mono">' +
			esc(p.stack.slice(0, 3).join(" / ")) +
			"</span>" +
			'<span class="arrow">→</span>' +
			"</div>" +
			"</article>"
		);
	}

	/* Kartu berita biasa. */
	function ncard(post) {
		return (
			'<a class="ncard" href="berita-detail.html?slug=' +
			esc(post.slug) +
			'" data-reveal>' +
			'<div class="ncard__art">' +
			U.art(post.variant, glyphOf(post.kategori)) +
			"</div>" +
			'<span class="label label--mark">' +
			esc(post.kategori) +
			"</span>" +
			'<h3 class="ncard__title">' +
			esc(post.title) +
			"</h3>" +
			'<p class="ncard__excerpt">' +
			esc(post.excerpt) +
			"</p>" +
			'<div class="ncard__meta"><span>' +
			U.tanggalPendek(post.tanggal) +
			"</span><span>" +
			esc(post.baca) +
			" menit baca</span></div>" +
			"</a>"
		);
	}

	/* Baris indeks berita (kolom sempit, tanpa gambar). */
	function irow(post) {
		return (
			'<a class="irow" href="berita-detail.html?slug=' +
			esc(post.slug) +
			'" data-reveal>' +
			'<span class="label">' +
			esc(post.kategori) +
			"</span>" +
			'<h3 class="irow__title">' +
			esc(post.title) +
			"</h3>" +
			'<p class="irow__excerpt">' +
			esc(post.excerpt) +
			"</p>" +
			'<div class="irow__meta"><span>' +
			U.tanggalPendek(post.tanggal) +
			"</span><span>" +
			esc(post.penulis) +
			"</span></div>" +
			"</a>"
		);
	}

	function tickerItems(el, items, dot) {
		if (!el) return;
		const body = items
			.map(
				(t) =>
					'<span class="ticker__item">' +
					t +
					(dot ? '<span class="ticker__dot"></span>' : "") +
					"</span>",
			)
			.join("");
		el.innerHTML = '<div class="ticker__track">' + body + "</div>";
	}

	/* =====================================================
	   Bagian yang muncul di semua halaman (footer)
	   ===================================================== */
	function renderPartners() {
		const grid = U.qs("#partnerGrid");
		if (grid) {
			set(
				grid,
				D.partners
					.map(
						(p) =>
							'<a class="plogo" href="' +
							esc(p.url) +
							'" data-no-router="true">' +
							'<span class="plogo__slot">' +
							(p.izinTampil ? "LOGO" : glyphOf(p.nama)) +
							"</span>" +
							'<span class="plogo__name">' +
							esc(p.nama) +
							"</span>" +
							'<span class="plogo__tier">' +
							esc(p.tier) +
							"</span>" +
							"</a>",
					)
					.join(""),
			);
		}

		tickerItems(
			U.qs("#partnerTicker"),
			D.partners.map((p) => esc(p.nama) + " <em>" + esc(p.tier) + "</em>"),
			true,
		);
	}

	/* =====================================================
	   HALAMAN DEPAN
	   ===================================================== */
	function renderHome(root) {
		/* Ticker hero: nama project anggota. */
		tickerItems(
			U.qs("#heroTicker", root),
			D.projects.map((p) => esc(p.title) + " <em>" + esc(p.tahun) + "</em>"),
			true,
		);

		/* Baris bukti dengan angka berhitung. */
		set(
			U.qs("#proof", root),
			D.stats
				.map(
					(s) =>
						'<div class="proof__item" data-reveal>' +
						'<span class="proof__num" data-counter="' +
						s.value +
						'" data-suffix="' +
						esc(s.suffix || "") +
						'">0</span>' +
						'<span class="proof__label">' +
						esc(s.label) +
						"</span>" +
						"</div>",
				)
				.join(""),
		);

		set(
			U.qs("#pillars", root),
			D.pillars
				.map(
					(p) =>
						'<div class="pillar" data-reveal>' +
						'<span class="pillar__num">' +
						esc(p.num) +
						"</span>" +
						'<h3 class="pillar__title">' +
						esc(p.title) +
						"</h3>" +
						'<p class="pillar__text">' +
						esc(p.text) +
						"</p>" +
						"</div>",
				)
				.join(""),
		);

		/* Bento: satu kartu tinggi, satu lebar, sisanya normal. */
		const featured = D.projects.filter((p) => p.featured).slice(0, 3);
		const sizes = ["", "", ""];
		set(
			U.qs("#featuredProjects", root),
			featured.map((p, i) => pcard(p, sizes[i] || "", i)).join(""),
		);

		/* Berita: dua kartu besar + daftar ringkas. */
		const posts = D.posts.slice(0, 6);
		const latest = U.qs("#latestPosts", root);
		if (latest) {
			set(
				latest,
				'<div class="asym__major">' +
					posts.slice(0, 2).map(ncard).join("") +
					"</div>" +
					'<div class="asym__minor">' +
					posts.slice(2, 6).map(irow).join("") +
					"</div>",
			);
		}

		set(
			U.qs("#org", root),
			D.divisions
				.map(
					(d, i) =>
						'<div class="org__card" data-reveal>' +
						'<span class="idx">0' +
						(i + 1) +
						"</span>" +
						"<h3>" +
						esc(d.name) +
						"</h3>" +
						'<p class="dek">' +
						esc(d.text) +
						"</p>" +
						'<div class="org__list">' +
						d.focus.map((f) => "<span>" + esc(f) + "</span>").join("") +
						"</div>" +
						"</div>",
				)
				.join(""),
		);

		set(
			U.qs("#ig", root),
			D.instagram
				.map(
					(g) =>
						'<a class="igtile" href="' +
						esc(D.settings.instagramUrl) +
						'" target="_blank" rel="noopener" data-no-router="true" data-reveal="scale">' +
						U.art(g.variant, "IG") +
						'<span class="igtile__overlay">' +
						esc(g.caption) +
						"</span>" +
						"</a>",
				)
				.join(""),
		);
	}

	/* =====================================================
	   BERITA (daftar)
	   ===================================================== */
	function renderBerita(root) {
		const lead = D.posts.find((p) => p.featured) || D.posts[0];
		const side = D.posts.filter((p) => p.slug !== lead.slug).slice(0, 3);

		set(
			U.qs("#magazine", root),
			'<a class="magazine__lead" href="berita-detail.html?slug=' +
				esc(lead.slug) +
				'" data-reveal>' +
				'<div class="magazine__art">' +
				U.art(lead.variant, glyphOf(lead.kategori)) +
				"</div>" +
				'<span class="label label--mark">' +
				esc(lead.kategori) +
				"</span>" +
				'<h2 class="magazine__title">' +
				esc(lead.title) +
				"</h2>" +
				'<p class="lead">' +
				esc(lead.excerpt) +
				"</p>" +
				'<div class="ncard__meta"><span>' +
				U.tanggalPanjang(lead.tanggal) +
				"</span><span>" +
				esc(lead.penulis) +
				"</span></div>" +
				"</a>" +
				'<div class="magazine__side" data-stagger="70">' +
				side
					.map(
						(p) =>
							'<a class="sidepost" href="berita-detail.html?slug=' +
							esc(p.slug) +
							'" data-reveal>' +
							'<span class="label">' +
							esc(p.kategori) +
							"</span>" +
							'<h3 class="sidepost__title">' +
							esc(p.title) +
							"</h3>" +
							'<span class="idx">' +
							U.tanggalPendek(p.tanggal) +
							"</span>" +
							"</a>",
					)
					.join("") +
				"</div>",
		);

		/* Chip kategori (tampilan saja) dengan jumlah per kategori. */
		set(
			U.qs("#postChips", root),
			D.postCategories
				.map((c, i) => {
					const n =
						c === "Semua"
							? D.posts.length
							: D.posts.filter((p) => p.kategori === c).length;
					return (
						'<button class="chip' +
						(i === 0 ? " is-active" : "") +
						'" type="button" aria-pressed="' +
						(i === 0) +
						'">' +
						esc(c) +
						'<span class="chip__count">' +
						n +
						"</span></button>"
					);
				})
				.join(""),
		);

		const rest = D.posts.slice(1);
		set(U.qs("#postMajor", root), rest.slice(0, 4).map(ncard).join(""));
		set(U.qs("#postMinor", root), rest.slice(4).map(irow).join(""));
	}

	/* =====================================================
	   BERITA (detail)
	   ===================================================== */
	function bodyProse(post) {
		/* Isi artikel masih contoh: dirakit dari ringkasan + lembar fakta,
		   supaya tata letak teks panjang bisa dinilai dengan jujur. */
		return (
			"<p>" +
			esc(post.excerpt) +
			"</p>" +
			"<p>Kegiatan ini dijalankan bersama pengurus dari tiga divisi. Persiapan dimulai beberapa pekan sebelumnya, mulai dari penyusunan rundown, pembagian peran, sampai penyiapan perangkat teknis yang dipakai peserta.</p>" +
			'<blockquote class="pull">Yang kami kejar bukan keramaian sesaat, tapi catatan yang bisa dipakai pengurus berikutnya.</blockquote>' +
			"<h2>Jalannya kegiatan</h2>" +
			"<p>Sesi dibuka dengan pemaparan singkat, lalu dilanjutkan bagian praktik. Peserta mengerjakan studi kasus dan mendapat umpan balik langsung dari mentor internal UKM.</p>" +
			"<ul><li>Pendaftaran dan verifikasi peserta berjalan lewat portal internal.</li><li>Materi disiapkan Divisi Program Development.</li><li>Dokumentasi dan publikasi ditangani Divisi Media Design & Partnership.</li></ul>" +
			"<h2>Tindak lanjut</h2>" +
			"<p>Hasil kegiatan diarsipkan di situs ini beserta lembar fakta di bawah, sehingga media dan calon partner bisa memakai datanya tanpa perlu bertanya ulang.</p>"
		);
	}

	function factsheet(post) {
		const f = post.fact || {};
		const rows = [
			["Tanggal acara", f.tanggalAcara],
			["Format", f.format],
			["Peserta", f.peserta],
			["Kolaborator", f.kolaborator],
		];
		return (
			'<section class="factsheet" data-reveal>' +
			'<div class="factsheet__head"><span class="label">Lembar fakta</span><span class="idx">UNTUK MEDIA</span></div>' +
			'<div class="factsheet__grid">' +
			rows
				.map(
					(r) =>
						'<div class="factsheet__cell"><span class="label">' +
						esc(r[0]) +
						"</span><strong>" +
						esc(r[1] || "—") +
						"</strong></div>",
				)
				.join("") +
			"</div>" +
			"</section>"
		);
	}

	function renderBeritaDetail(root) {
		const slug = U.param("slug");
		const i = Math.max(
			0,
			D.posts.findIndex((p) => p.slug === slug),
		);
		const post = D.posts[i] || D.posts[0];

		set(
			U.qs("#article", root),
			'<header class="article__head">' +
				'<span class="label label--mark">' +
				esc(post.kategori) +
				"</span>" +
				'<h1 class="article__title"><span class="lineMask"><span>' +
				esc(post.title) +
				"</span></span></h1>" +
				'<div class="article__meta"><span>' +
				U.tanggalPanjang(post.tanggal) +
				"</span><span>" +
				esc(post.penulis) +
				"</span><span>" +
				esc(post.baca) +
				" menit baca</span></div>" +
				"</header>" +
				'<div class="article__cover">' +
				U.art(post.variant, glyphOf(post.kategori)) +
				"</div>" +
				'<div class="prose">' +
				bodyProse(post) +
				"</div>" +
				factsheet(post) +
				'<div class="share"><span class="label">Bagikan</span><a class="tlink" href="#" data-no-router="true">Salin tautan</a><a class="tlink" href="#" data-no-router="true">WhatsApp</a><a class="tlink" href="#" data-no-router="true">X</a></div>',
		);

		const prev = D.posts[i - 1];
		const next = D.posts[i + 1];
		set(
			U.qs("#postNav", root),
			(prev
				? '<a class="pagenav__item" href="berita-detail.html?slug=' +
					esc(prev.slug) +
					'"><span class="label">← Sebelumnya</span><strong>' +
					esc(prev.title) +
					"</strong></a>"
				: '<span class="pagenav__item"><span class="label">Awal arsip</span><strong>Tidak ada catatan sebelumnya</strong></span>') +
				(next
					? '<a class="pagenav__item pagenav__item--next" href="berita-detail.html?slug=' +
						esc(next.slug) +
						'"><span class="label">Berikutnya →</span><strong>' +
						esc(next.title) +
						"</strong></a>"
					: '<span class="pagenav__item pagenav__item--next"><span class="label">Akhir arsip</span><strong>Tidak ada catatan berikutnya</strong></span>'),
		);
	}

	/* =====================================================
	   SHOWCASE (daftar)
	   ===================================================== */
	function renderShowcase(root) {
		set(
			U.qs("#projectChips", root),
			D.projectCategories
				.map((c, i) => {
					const n =
						c === "Semua"
							? D.projects.length
							: D.projects.filter((p) => p.kategori === c).length;
					return (
						'<button class="chip' +
						(i === 0 ? " is-active" : "") +
						'" type="button" aria-pressed="' +
						(i === 0) +
						'">' +
						esc(c) +
						'<span class="chip__count">' +
						n +
						"</span></button>"
					);
				})
				.join(""),
		);

		/* Pola bento berulang: tinggi → normal → normal → lebar → normal → normal. */
		const pattern = ["tall", "", "", "wide", "", ""];
		set(
			U.qs("#projectGrid", root),
			D.projects.map((p, i) => pcard(p, pattern[i % pattern.length], i)).join(""),
		);
	}

	/* =====================================================
	   SHOWCASE (studi kasus)
	   ===================================================== */
	function renderShowcaseDetail(root) {
		const slug = U.param("slug");
		const i = Math.max(
			0,
			D.projects.findIndex((p) => p.slug === slug),
		);
		const p = D.projects[i] || D.projects[0];

		set(
			U.qs("#caseHead", root),
			'<div class="breadcrumb"><a href="index.html">Beranda</a><span>/</span><a href="showcase.html">Showcase</a><span>/</span><span>' +
				esc(p.kategori) +
				"</span></div>" +
				'<h1 class="pagehead__title"><span class="lineMask"><span>' +
				esc(p.title) +
				"</span></span></h1>" +
				'<div class="pagehead__foot">' +
				'<p class="lead" data-reveal style="--reveal-delay:340ms">' +
				esc(p.oneLiner) +
				"</p>" +
				'<span class="idx">' +
				esc(p.jenis) +
				" · " +
				esc(p.tahun) +
				"</span>" +
				"</div>" +
				'<div class="case-hero__art" data-reveal="scale">' +
				U.art(p.variant, glyphOf(p.title)) +
				"</div>",
		);

		const specRows = [
			["Kategori", p.kategori],
			["Jenis", p.jenis],
			["Tahun", p.tahun],
			["Peran", p.peran],
			["Durasi", p.durasi],
			["Status", p.status],
			["Kontributor", p.kontributor],
		];

		set(
			U.qs("#case", root),
			'<div class="case__layout">' +
				'<aside class="case__aside">' +
				'<span class="label">Spesifikasi</span>' +
				'<div class="spec">' +
				specRows
					.map(
						(r) =>
							'<div class="spec__row"><span class="spec__k">' +
							esc(r[0]) +
							'</span><span class="spec__v">' +
							esc(r[1] || "—") +
							"</span></div>",
					)
					.join("") +
				"</div>" +
				'<div class="stackpills">' +
				p.stack.map((s) => '<span class="stackpill">' + esc(s) + "</span>").join("") +
				"</div>" +
				'<div class="stack" style="gap:10px">' +
				'<a class="btn btn--mark btn--block" href="' +
				esc(p.demoUrl || "#") +
				'" data-no-router="true">Lihat demo</a>' +
				'<a class="btn btn--block" href="' +
				esc(p.repoUrl || "#") +
				'" data-no-router="true">Repositori</a>' +
				"</div>" +
				"</aside>" +
				'<div class="case__prose prose" data-stagger="70">' +
				'<h2 data-reveal>Masalah</h2>' +
				"<p data-reveal>" +
				esc(p.masalah) +
				"</p>" +
				'<h2 data-reveal>Pendekatan</h2>' +
				'<div class="steps">' +
				p.pendekatan
					.map(
						(s, n) =>
							'<div class="step" data-reveal><span class="step__dot"></span><span class="label">Tahap 0' +
							(n + 1) +
							"</span><p>" +
							esc(s) +
							"</p></div>",
					)
					.join("") +
				"</div>" +
				'<h2 data-reveal>Hasil</h2>' +
				"<ul data-reveal>" +
				p.hasil.map((h) => "<li>" + esc(h) + "</li>").join("") +
				"</ul>" +
				'<blockquote class="pull" data-reveal>' +
				esc(p.pelajaran) +
				"</blockquote>" +
				'<h2 data-reveal>Tampilan</h2>' +
				'<div class="gallery">' +
				'<div class="gallery__cell gallery__cell--wide" data-reveal>' +
				U.art(p.variant, "01") +
				"</div>" +
				'<div class="gallery__cell" data-reveal>' +
				U.art("neutral", "02") +
				"</div>" +
				'<div class="gallery__cell" data-reveal>' +
				U.art(p.variant === "blue" ? "orange" : "blue", "03") +
				"</div>" +
				"</div>" +
				"</div>" +
				"</div>",
		);

		const prev = D.projects[i - 1];
		const next = D.projects[i + 1];
		set(
			U.qs("#caseNav", root),
			(prev
				? '<a class="pagenav__item" href="showcase-detail.html?slug=' +
					esc(prev.slug) +
					'"><span class="label">← Project sebelumnya</span><strong>' +
					esc(prev.title) +
					"</strong></a>"
				: '<span class="pagenav__item"><span class="label">Awal daftar</span><strong>Tidak ada project sebelumnya</strong></span>') +
				(next
					? '<a class="pagenav__item pagenav__item--next" href="showcase-detail.html?slug=' +
						esc(next.slug) +
						'"><span class="label">Project berikutnya →</span><strong>' +
						esc(next.title) +
						"</strong></a>"
					: '<span class="pagenav__item pagenav__item--next"><span class="label">Akhir daftar</span><strong>Tidak ada project berikutnya</strong></span>'),
		);
	}

	/* =====================================================
	   MODAL LIHAT CEPAT
	   ===================================================== */
	function fillProjectModal(slug) {
		const p = D.projects.find((x) => x.slug === slug);
		const body = U.qs("#projectModalBody");
		if (!p || !body) return;

		body.innerHTML =
			'<div class="modal__art">' +
			U.art(p.variant, glyphOf(p.title)) +
			"</div>" +
			'<div class="modal__body">' +
			'<span class="label label--mark">' +
			esc(p.kategori) +
			" · " +
			esc(p.tahun) +
			"</span>" +
			'<h2 id="projectModalTitle">' +
			esc(p.title) +
			"</h2>" +
			'<p class="dek">' +
			esc(p.oneLiner) +
			"</p>" +
			'<div class="spec">' +
			'<div class="spec__row"><span class="spec__k">Peran</span><span class="spec__v">' +
			esc(p.peran) +
			"</span></div>" +
			'<div class="spec__row"><span class="spec__k">Status</span><span class="spec__v">' +
			esc(p.status) +
			"</span></div>" +
			'<div class="spec__row"><span class="spec__k">Kontributor</span><span class="spec__v">' +
			esc(p.kontributor) +
			"</span></div>" +
			"</div>" +
			'<div class="stackpills">' +
			p.stack.map((s) => '<span class="stackpill">' + esc(s) + "</span>").join("") +
			"</div>" +
			'<div class="row">' +
			'<a class="btn btn--primary" href="showcase-detail.html?slug=' +
			esc(p.slug) +
			'">Studi kasus penuh <span class="arrow">→</span></a>' +
			'<a class="btn" href="' +
			esc(p.repoUrl || "#") +
			'" data-no-router="true">Repositori</a>' +
			"</div>" +
			"</div>";
	}

	function initProjectCards(root) {
		const modal = U.qs("#projectModal");
		if (!modal) return;
		U.qsa("[data-project]", root).forEach((card) => {
			const open = () => {
				fillProjectModal(card.getAttribute("data-project"));
				U.openModal(modal);
			};
			card.addEventListener("click", open);
			card.addEventListener("keydown", (e) => {
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault();
					open();
				}
			});
		});
	}

	/* =====================================================
	   ADMIN (mockup)
	   ===================================================== */
	function badgeFor(i) {
		if (i % 5 === 0) return '<span class="badge badge--review">Review</span>';
		if (i % 7 === 0) return '<span class="badge badge--draft">Draf</span>';
		return '<span class="badge badge--published">Terbit</span>';
	}

	function renderAdmin(root) {
		const cards = [
			{ label: "Berita", value: D.posts.length, delta: "3 terbit bulan ini" },
			{ label: "Project", value: D.projects.length, delta: "2 menunggu studi kasus" },
			{ label: "Menunggu review", value: 3, delta: "Perlu tindakan editor" },
			{ label: "Unduh deck", value: 46, delta: "30 hari terakhir" },
		];
		set(
			U.qs("#adminStats", root),
			cards
				.map(
					(c) =>
						'<div class="stat"><span class="stat__label">' +
						esc(c.label) +
						'</span><span class="stat__value">' +
						c.value +
						'</span><span class="stat__delta">' +
						esc(c.delta) +
						"</span></div>",
				)
				.join(""),
		);

		set(
			U.qs("#adminPosts", root),
			D.posts
				.slice(0, 8)
				.map(
					(p, i) =>
						"<tr>" +
						'<td><a class="table__title" href="editor.html">' +
						esc(p.title) +
						'</a><span class="table__sub">/' +
						esc(p.slug) +
						"</span></td>" +
						'<td><span class="tag tag--plain">' +
						esc(p.kategori) +
						"</span></td>" +
						"<td>" +
						badgeFor(i) +
						"</td>" +
						'<td class="mono">' +
						U.tanggalPendek(p.tanggal) +
						"</td>" +
						"</tr>",
				)
				.join(""),
		);

		set(
			U.qs("#adminActivity", root),
			D.adminActivity
				.map(
					(a, i) =>
						'<div class="flow__step ' +
						(i === 0 ? "is-current" : "is-done") +
						'"><span class="flow__dot"></span><div><strong>' +
						esc(a.aksi) +
						"</strong> · " +
						esc(a.objek) +
						'<span class="table__sub">' +
						esc(a.oleh) +
						" · " +
						esc(a.waktu) +
						"</span></div></div>",
				)
				.join(""),
		);
	}

	function renderAdminEditor(root) {
		const sel = U.qs("#kategori", root);
		if (sel) {
			sel.innerHTML = D.postCategories
				.filter((c) => c !== "Semua")
				.map((c) => "<option>" + esc(c) + "</option>")
				.join("");
		}

		set(
			U.qs("#settingsFields", root),
			D.stats
				.map(
					(s, i) =>
						'<div class="field"><label class="label" for="stat' +
						i +
						'">' +
						esc(s.label) +
						'</label><input class="input" id="stat' +
						i +
						'" type="number" value="' +
						s.value +
						'" /></div>',
				)
				.join(""),
		);
	}

	/* =====================================================
	   Dispatcher
	   ===================================================== */
	function mount(root) {
		const scope = root || document;
		const page = document.body.getAttribute("data-page");

		if (page === "home") renderHome(scope);
		else if (page === "berita") renderBerita(scope);
		else if (page === "berita-detail") renderBeritaDetail(scope);
		else if (page === "showcase") renderShowcase(scope);
		else if (page === "showcase-detail") renderShowcaseDetail(scope);
		else if (page === "admin") renderAdmin(scope);
		else if (page === "admin-editor") renderAdminEditor(scope);

		fillSettings();
		U.markActiveNav();
		U.fillYear();
		U.initModals();
		U.initChipsVisual(scope);
		U.initPaginationVisual(scope);
		U.initSwitches(scope);
		initProjectCards(scope);

		if (M) {
			M.initAll(scope);
			M.playHero(scope);
		}
	}

	function boot() {
		U.initHeader();
		U.initDrawer();
		renderPartners();
		mount(U.qs("#page") || document);
		if (M) M.initTicker(document);
	}

	return { boot: boot, mount: mount, fillProjectModal: fillProjectModal };
})();
