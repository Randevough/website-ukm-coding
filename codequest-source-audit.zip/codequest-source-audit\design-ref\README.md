# UKM Coding Cyber University — Prototype Desain v2

Prototype **desain saja** (HTML + CSS + JS murni, tanpa build step, tanpa dependensi).
Semua logika sungguhan — CMS, autentikasi, filter, pagination, upload — dikerjakan nanti
di stack sebenarnya. Berkas ini dipakai sebagai acuan visual dan interaksi.

## Cara menjalankan

```bash
cd ukm-coding-prototype
python3 -m http.server 5173   # atau: npx serve .
```

Buka `http://localhost:5173`.

Bisa juga dibuka langsung lewat `file://` — router antar-halaman otomatis mematikan
dirinya (`location.protocol === "file:"`) dan navigasi jatuh ke pemuatan halaman biasa.
Untuk melihat transisi halaman fade + geser, jalankan lewat server lokal.

> Font dimuat dari Google Fonts. Tanpa internet, sistem font pengganti dipakai dan
> konsol menampilkan `ERR_NAME_NOT_RESOLVED` — itu wajar, bukan kerusakan.

## Isi berkas

```
index.html              Halaman depan
berita.html             Arsip berita (hero majalah + kolom asimetris)
berita-detail.html      Satu berita + lembar fakta untuk media
showcase.html           Kisi bento seluruh project
showcase-detail.html    Studi kasus penuh (aside sticky)
admin/login.html        Mockup masuk pengurus
admin/index.html        Mockup dashboard
admin/editor.html       Mockup editor berita

assets/css/tokens.css       Variabel: warna, tipografi, jarak, easing, z-index
assets/css/base.css         Reset, tipografi dasar, grain, rails, layout dasar
assets/css/components.css   Komponen lintas halaman (kartu, tombol, modal, ticker, footer)
assets/css/pages.css        Bagian khusus per halaman (hero, bento, artikel, studi kasus)
assets/css/admin.css        Panel pengurus

assets/js/data.js       Seluruh konten contoh (window.UKM)
assets/js/ui.js         Utilitas + perilaku dasar (header, drawer, modal, chip, switch)
assets/js/motion.js     Semua gerak: reveal, lineMask, parallax, counter, tilt, kursor, ticker
assets/js/render.js     Mengisi slot halaman dari data (window.App.boot / mount)
assets/js/router.js     Transisi antar-halaman tanpa reload penuh
```

Urutan skrip halaman publik: `data.js → ui.js → motion.js → render.js → router.js`,
lalu `window.App.boot()`. Halaman admin sama, tanpa `router.js`.

## Arah desain

Dasarnya **"spec sheet"**: garis rambut, label mono huruf besar, nomor urut bagian,
tabel spesifikasi, kertas hangat (bukan putih murni). Biru dan oranye hanya aksen —
ditukar per halaman lewat `data-mark="blue|orange"` pada `<body>` atau pada satu bagian.
Serif (Instrument Serif) dibatasi untuk pull quote dan penekanan miring saja.

Tekstur berlapis: grain halus di seluruh halaman, garis rambut vertikal (`.rails`),
dan grafik samar (`.graph`) pada bagian tertentu.

Tidak ada foto anggota maupun kegiatan. Semua visual adalah gambar geometris CSS
(`.art`, empat varian warna) sehingga situs tetap rapi sebelum aset foto tersedia.
Slot logo sengaja dikosongkan sampai izin pemasangan dikonfirmasi.

## Gerak

Semua diatur lewat atribut, dibaca `motion.js`, dan otomatis dimatikan bila
`prefers-reduced-motion: reduce`.

| Atribut | Efek |
| --- | --- |
| `data-reveal` (`fade`/`left`/`scale`) | Muncul saat masuk layar |
| `data-stagger="90"` | Memberi jeda beruntun ke anak-anaknya |
| `--reveal-delay` | Jeda manual satu elemen |
| `.lineMask` | Baris judul naik dari masker |
| `data-parallax="0.06"` | Pergeseran kedalaman saat scroll |
| `data-counter` + `data-suffix` | Angka berhitung naik |
| `data-tilt` | Kartu miring mengikuti kursor |
| `data-cursor="Lihat cepat"` | Label kursor kustom di area tertentu |
| `.ticker` | Baris berjalan (isi diklon supaya mulus) |
| `.hero__wash` | Sapuan gradient mengikuti pointer |

## Yang sudah berfungsi vs sekadar tampilan

**Berfungsi:** navigasi antar-halaman (dengan transisi), drawer mobile, modal lihat
cepat project (klik dan Enter/Space), navigasi sebelumnya/berikutnya di halaman detail,
rute detail lewat `?slug=`, tombol Esc menutup modal & drawer, switch di editor.

**Tampilan saja:** filter kategori, urutan, pagination, pencarian, unggah berkas,
formulir masuk (tombol langsung membuka dashboard contoh), semua tombol simpan/terbit.

## Angka & konten

Semua angka dan teks di `data.js` masih contoh: 24+ kegiatan, 32 anggota aktif,
41 institusi peserta, 27 project. Tahun berdiri belum diisi (`tahunBerdiri: ""`),
jadi hero menampilkan `EST. —`. Semua media partner disetel `izinTampil: false`
sehingga hanya nama teks yang muncul, bukan logo.

## Rencana porting ke stack sebenarnya

Target: **Next.js 15 (App Router) + TypeScript + Tailwind**, **Payload CMS 3** di `/admin`,
**Supabase** (Postgres + Storage), deploy di **Vercel**.

| Prototype | Nanti |
| --- | --- |
| `tokens.css` | `tailwind.config.ts` + `globals.css` |
| header & drawer | `site-header.tsx`, `mobile-drawer.tsx` |
| hero | `components/hero/*` (`"use client"`) |
| baris bukti | `proof-strip.tsx` (angka dari Globals: Settings) |
| kartu | `project-card.tsx`, `post-card.tsx` |
| modal lihat cepat | `project-quick-view.tsx` (Radix Dialog) |
| `berita.html` | `app/berita/page.tsx` dengan `searchParams` `?kategori=&q=&page=` |
| halaman detail | `app/berita/[slug]`, `app/showcase/[slug]` + `generateStaticParams` |
| lembar fakta | `fact-sheet.tsx` |
| `admin/*` | dihapus — pakai panel Payload bawaan |
| `data.js` | koleksi Payload: Posts, Projects, Partners, Media, Users, Globals |
| `router.js`, `render.js` | dihapus — ditangani App Router & server component |
| `ui.js` | hook kecil (`useLockScroll`, `useDrawer`) |
| `motion.js` | Framer Motion, atau CSS + `useInView` bila ingin bundel tetap kecil |

Saat porting, pertahankan token dan skala tipografi apa adanya — di situlah karakter
visualnya berada. Ganti `.art` geometris dengan foto/tangkapan layar sungguhan hanya
kalau kualitasnya konsisten; kalau tidak, biarkan geometris.
