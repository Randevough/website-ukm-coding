/* =========================================================
   UI — utilitas + perilaku dasar (header, drawer, modal,
   chip, paginasi, switch, tautan aktif)
   Semua yang berhubungan dengan GERAK ada di motion.js
   ========================================================= */

window.UI = (function () {
	"use strict";

	const qs = (sel, root) => (root || document).querySelector(sel);
	const qsa = (sel, root) =>
		Array.prototype.slice.call((root || document).querySelectorAll(sel));

	function esc(str) {
		return String(str == null ? "" : str)
			.replace(/&/g, "&amp;")
			.replace(/</g, "&lt;")
			.replace(/>/g, "&gt;")
			.replace(/"/g, "&quot;");
	}

	/* ---------- Seni geometris (pengganti gambar) ---------- */
	const VAR_MAP = { blue: "1", mix: "2", orange: "3", neutral: "4" };

	function art(variant, glyph) {
		const v = VAR_MAP[variant] || "2";
		return (
			'<div class="art" data-v="' +
			v +
			'" aria-hidden="true">' +
			'<div class="art__wash"></div>' +
			'<div class="art__mesh"></div>' +
			'<div class="art__ring"></div>' +
			(glyph ? '<div class="art__glyph">' + esc(glyph) + "</div>" : "") +
			"</div>"
		);
	}

	/* ---------- Tanggal ---------- */
	const BULAN = [
		"Januari",
		"Februari",
		"Maret",
		"April",
		"Mei",
		"Juni",
		"Juli",
		"Agustus",
		"September",
		"Oktober",
		"November",
		"Desember",
	];

	function tanggalPanjang(iso) {
		const d = new Date(iso + "T00:00:00");
		if (isNaN(d)) return iso;
		return d.getDate() + " " + BULAN[d.getMonth()] + " " + d.getFullYear();
	}

	function tanggalPendek(iso) {
		const d = new Date(iso + "T00:00:00");
		if (isNaN(d)) return iso;
		return (
			d.getDate() + " " + BULAN[d.getMonth()].slice(0, 3) + " " + d.getFullYear()
		);
	}

	function param(name) {
		return new URLSearchParams(window.location.search).get(name);
	}

	/* ---------- Kunci scroll ---------- */
	let lockCount = 0;

	function lock() {
		lockCount++;
		document.body.classList.add("is-locked");
	}

	function unlock() {
		lockCount = Math.max(0, lockCount - 1);
		if (lockCount === 0) document.body.classList.remove("is-locked");
	}

	/* ---------- Header ---------- */
	function initHeader() {
		const header = qs(".site-header");
		if (!header) return;
		const onScroll = () => {
			header.classList.toggle("is-stuck", window.scrollY > 8);
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
	}

	/* ---------- Drawer ---------- */
	function initDrawer() {
		const drawer = qs("#drawer");
		const burger = qs("#burger");
		if (!drawer || !burger) return;

		const open = () => {
			drawer.classList.add("is-open");
			drawer.setAttribute("aria-hidden", "false");
			burger.setAttribute("aria-expanded", "true");
			lock();
			const first = qs(".drawer__close", drawer);
			if (first) first.focus();
		};

		const close = () => {
			if (!drawer.classList.contains("is-open")) return;
			drawer.classList.remove("is-open");
			drawer.setAttribute("aria-hidden", "true");
			burger.setAttribute("aria-expanded", "false");
			unlock();
		};

		burger.addEventListener("click", open);
		qsa("[data-drawer-close]", drawer).forEach((el) =>
			el.addEventListener("click", close),
		);
		UIapi._closeDrawer = close;
	}

	/* ---------- Modal ---------- */
	let lastFocused = null;

	function openModal(id) {
		const modal = typeof id === "string" ? qs("#" + id) : id;
		if (!modal) return;
		lastFocused = document.activeElement;
		modal.classList.add("is-open");
		modal.setAttribute("aria-hidden", "false");
		lock();
		const close = qs(".modal__close", modal);
		if (close) close.focus();
	}

	function closeModal(id) {
		const modal = typeof id === "string" ? qs("#" + id) : id;
		if (!modal || !modal.classList.contains("is-open")) return;
		modal.classList.remove("is-open");
		modal.setAttribute("aria-hidden", "true");
		unlock();
		if (lastFocused && lastFocused.focus) lastFocused.focus();
	}

	function closeAllModals() {
		qsa(".modal.is-open").forEach((m) => closeModal(m));
	}

	function initModals() {
		qsa(".modal").forEach((modal) => {
			qsa("[data-modal-close]", modal).forEach((el) =>
				el.addEventListener("click", () => closeModal(modal)),
			);
		});
	}

	/* ---------- Esc global ---------- */
	document.addEventListener("keydown", (e) => {
		if (e.key !== "Escape") return;
		closeAllModals();
		if (UIapi._closeDrawer) UIapi._closeDrawer();
	});

	/* ---------- Chip filter (visual saja) ---------- */
	function initChipsVisual(root) {
		qsa("[data-chips]", root || document).forEach((group) => {
			group.addEventListener("click", (e) => {
				const chip = e.target.closest(".chip");
				if (!chip || !group.contains(chip)) return;
				qsa(".chip", group).forEach((c) => {
					c.classList.remove("is-active");
					c.setAttribute("aria-pressed", "false");
				});
				chip.classList.add("is-active");
				chip.setAttribute("aria-pressed", "true");
			});
		});
	}

	/* ---------- Paginasi (visual saja) ---------- */
	function initPaginationVisual(root) {
		qsa("[data-pagination]", root || document).forEach((nav) => {
			nav.addEventListener("click", (e) => {
				const btn = e.target.closest("[data-page-num]");
				if (!btn || btn.disabled) return;
				qsa("[data-page-num]", nav).forEach((b) =>
					b.classList.remove("is-active"),
				);
				btn.classList.add("is-active");
			});
		});
	}

	/* ---------- Switch (admin) ---------- */
	function initSwitches(root) {
		qsa('[role="switch"]', root || document).forEach((sw) => {
			sw.addEventListener("click", () => {
				const on = sw.getAttribute("aria-checked") === "true";
				sw.setAttribute("aria-checked", on ? "false" : "true");
			});
		});
	}

	/* ---------- Tautan aktif & tahun ---------- */
	function markActiveNav() {
		const file = (window.location.pathname.split("/").pop() || "index.html")
			.toLowerCase();
		qsa("[data-nav]").forEach((link) => {
			const matches = link.getAttribute("data-nav").split(",");
			if (matches.indexOf(file) !== -1) link.classList.add("is-active");
			else link.classList.remove("is-active");
		});
	}

	function fillYear() {
		qsa("[data-year]").forEach((el) => {
			el.textContent = String(new Date().getFullYear());
		});
	}

	const UIapi = {
		qs: qs,
		qsa: qsa,
		esc: esc,
		art: art,
		tanggalPanjang: tanggalPanjang,
		tanggalPendek: tanggalPendek,
		param: param,
		lock: lock,
		unlock: unlock,
		openModal: openModal,
		closeModal: closeModal,
		closeAllModals: closeAllModals,
		initHeader: initHeader,
		initDrawer: initDrawer,
		initModals: initModals,
		initChipsVisual: initChipsVisual,
		initPaginationVisual: initPaginationVisual,
		initSwitches: initSwitches,
		markActiveNav: markActiveNav,
		fillYear: fillYear,
		_closeDrawer: null,
	};

	return UIapi;
})();
