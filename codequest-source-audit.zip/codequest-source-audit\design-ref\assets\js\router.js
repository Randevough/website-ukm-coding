/* =========================================================
   ROUTER — transisi halaman fade + geser halus
   Mengambil HTML halaman tujuan, menukar isi #page, lalu
   memasang ulang seluruh perilaku dan motion.
   Nonaktif otomatis saat dibuka lewat file:// (fetch diblokir
   browser) — dalam kondisi itu navigasi jadi biasa.
   ========================================================= */

(function () {
	"use strict";

	const OFFLINE = window.location.protocol === "file:";
	if (OFFLINE) return;

	const SAME_PAGE = ["index.html", "berita.html", "showcase.html"];
	const cache = new Map();

	function isInternal(a) {
		if (!a) return false;
		if (a.getAttribute("data-no-router") === "true") return false;
		if (a.target === "_blank") return false;
		const href = a.getAttribute("href") || "";
		if (!href || href.charAt(0) === "#") return false;
		if (/^(https?:|mailto:|tel:)/i.test(href)) return false;
		if (href.indexOf("admin/") === 0 || href.indexOf("../") === 0) return false;
		return /\.html(\?|$)/.test(href);
	}

	async function fetchPage(url) {
		if (cache.has(url)) return cache.get(url);
		const res = await fetch(url, { credentials: "same-origin" });
		const text = await res.text();
		cache.set(url, text);
		return text;
	}

	async function go(url, push) {
		const current = document.getElementById("page");
		if (!current) {
			window.location.href = url;
			return;
		}

		document.body.classList.add("is-leaving");

		try {
			const [html] = await Promise.all([
				fetchPage(url),
				new Promise((r) => setTimeout(r, 240)),
			]);

			const doc = new DOMParser().parseFromString(html, "text/html");
			const next = doc.getElementById("page");
			if (!next) {
				window.location.href = url;
				return;
			}

			/* Tukar isi + atribut halaman supaya CSS dan dispatch render
			   tahu sedang berada di halaman apa. */
			document.title = doc.title;
			document.body.setAttribute(
				"data-page",
				doc.body.getAttribute("data-page") || "",
			);
			const mark = doc.body.getAttribute("data-mark");
			if (mark) document.body.setAttribute("data-mark", mark);
			else document.body.removeAttribute("data-mark");

			current.replaceWith(next);

			if (push) window.history.pushState({}, "", url);
			window.scrollTo({ top: 0, behavior: "instant" });

			document.body.classList.remove("is-leaving", "is-locked");
			if (window.UI) window.UI.closeAllModals();
			if (window.App) window.App.mount(next);
		} catch (err) {
			window.location.href = url;
		}
	}

	document.addEventListener("click", (e) => {
		if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
		const a = e.target.closest("a");
		if (!isInternal(a)) return;
		e.preventDefault();
		if (window.UI && window.UI._closeDrawer) window.UI._closeDrawer();
		go(a.getAttribute("href"), true);
	});

	window.addEventListener("popstate", () => {
		go(window.location.pathname + window.location.search, false);
	});

	/* Pramuat halaman utama saat diam supaya transisi terasa instan. */
	if ("requestIdleCallback" in window) {
		window.requestIdleCallback(() => {
			SAME_PAGE.forEach((p) => fetchPage(p).catch(() => {}));
		});
	}
})();
