/**
 * Hero motion effects (Grid reveal by pointer)
 * Uses Astro Web Components (Custom Elements) to natively survive SPA swaps.
 */

const isBrowser = typeof window !== "undefined" && typeof document !== "undefined";
const reduce = isBrowser && typeof window.matchMedia === "function" ? window.matchMedia("(prefers-reduced-motion: reduce)").matches : false;

class GridReveal extends HTMLElement {
  private raf: number | null = null;
  private currentX = 0;
  private currentY = 0;
  private targetX = 0;
  private targetY = 0;
  private isHovering = false;
  private hasMoved = false;

  private parentSection: HTMLElement | null = null;

  constructor() {
    super();
    // Bind methods to ensure correct `this` context
    this.handlePointerEnter = this.handlePointerEnter.bind(this);
    this.handlePointerLeave = this.handlePointerLeave.bind(this);
    this.handlePointerMove = this.handlePointerMove.bind(this);
    this.loop = this.loop.bind(this);
  }

  connectedCallback() {
    if (!isBrowser || reduce) return;

    // Find the containing hero or pagehead section to track hover boundaries
    this.parentSection = this.closest(".hero--v2, .pagehead") as HTMLElement;
    if (!this.parentSection) return;

    this.parentSection.addEventListener("pointerenter", this.handlePointerEnter, { passive: true });
    this.parentSection.addEventListener("pointerleave", this.handlePointerLeave, { passive: true });
    this.parentSection.addEventListener("pointermove", this.handlePointerMove, { passive: true });
  }

  disconnectedCallback() {
    if (this.parentSection) {
      this.parentSection.removeEventListener("pointerenter", this.handlePointerEnter);
      this.parentSection.removeEventListener("pointerleave", this.handlePointerLeave);
      this.parentSection.removeEventListener("pointermove", this.handlePointerMove);
    }
    if (this.raf) {
      cancelAnimationFrame(this.raf);
      this.raf = null;
    }
  }

  private loop() {
    // Settle loop when destination is reached
    if (!this.isHovering && Math.abs(this.targetX - this.currentX) < 0.5 && Math.abs(this.targetY - this.currentY) < 0.5) {
      this.raf = null;
      return;
    }
    
    this.currentX += (this.targetX - this.currentX) * 0.12;
    this.currentY += (this.targetY - this.currentY) * 0.12;
    
    this.style.setProperty("--hero-mx", `${this.currentX.toFixed(1)}px`);
    this.style.setProperty("--hero-my", `${this.currentY.toFixed(1)}px`);
    
    this.raf = requestAnimationFrame(this.loop);
  }

  private handlePointerEnter() {
    this.isHovering = true;
    this.style.opacity = "0.18";
  }

  private handlePointerLeave() {
    this.isHovering = false;
    this.style.opacity = "0";
    if (!this.raf) {
      this.raf = requestAnimationFrame(this.loop);
    }
  }

  private handlePointerMove(e: PointerEvent) {
    if (!this.isHovering) {
      this.isHovering = true;
      this.style.opacity = "0.18";
    }

    // Since this custom element IS the grid, its getBoundingClientRect() directly accounts
    // for inset offsets. We don't need to offset by 15% manually.
    const rect = this.getBoundingClientRect();
    this.targetX = e.clientX - rect.left;
    this.targetY = e.clientY - rect.top;
    
    if (!this.hasMoved) {
      this.currentX = this.targetX;
      this.currentY = this.targetY;
      this.style.setProperty("--hero-mx", `${this.currentX.toFixed(1)}px`);
      this.style.setProperty("--hero-my", `${this.currentY.toFixed(1)}px`);
      this.hasMoved = true;
    }

    if (!this.raf) {
      this.raf = requestAnimationFrame(this.loop);
    }
  }
}

if (isBrowser) {
  // Define custom element only once safely
  if (!customElements.get("grid-reveal")) {
    customElements.define("grid-reveal", GridReveal);
  }
}
